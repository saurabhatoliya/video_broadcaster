# VideoBroadcaster

This repository contain Computer Vision based Video Broadcaster which can be used as virtual camera in many meeting applications like GoogleMeet, Zoom etc.